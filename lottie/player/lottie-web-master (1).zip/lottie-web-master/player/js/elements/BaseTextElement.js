var BaseTextElement = function (){
};

